// ./react-redux-client/src/actions/appActions.js

export const toggleAddTodo = () => {
  return {
    type: 'TOGGLE_ADD_TODO'
  }
}
